Arquivo zip gerado em: 05/11/2021 18:10:17 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: [Módulo 2] Übersort