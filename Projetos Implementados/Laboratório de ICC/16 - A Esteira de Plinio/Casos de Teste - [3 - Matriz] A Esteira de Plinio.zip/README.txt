Arquivo zip gerado em: 02/08/2021 10:27:15 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: [3 - Matriz] A Esteira de Plínio