Arquivo zip gerado em: 02/08/2021 12:20:26 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: [6 - Struct] Gerenciamento de estudantes