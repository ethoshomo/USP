Arquivo zip gerado em: 02/08/2021 12:17:42 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: [6 - Arquivos] Compilador JIT de Brainf*ck