Arquivo zip gerado em: 22/11/2021 22:06:53 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: [Exercício 3] Busca Indexada em Lista Encadeada