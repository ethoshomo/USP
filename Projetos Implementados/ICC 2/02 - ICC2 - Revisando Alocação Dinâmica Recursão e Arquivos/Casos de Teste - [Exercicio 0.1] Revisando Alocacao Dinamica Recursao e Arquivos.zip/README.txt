Arquivo zip gerado em: 19/08/2021 16:08:33 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: [Exercício 0.1] Revisando Alocação Dinâmica Recursão e Arquivos