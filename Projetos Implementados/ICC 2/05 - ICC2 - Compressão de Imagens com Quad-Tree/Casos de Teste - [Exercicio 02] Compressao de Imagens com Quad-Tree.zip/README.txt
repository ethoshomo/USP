Arquivo zip gerado em: 20/10/2021 12:17:51 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: [Exercício 02] Compressão de Imagens com Quad-Tree