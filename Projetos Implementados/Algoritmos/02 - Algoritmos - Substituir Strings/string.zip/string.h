
void iniciaVetor(char vetor[], int tamanho);
void corrigindoErro(char frase[], char erro[], char correto[]);