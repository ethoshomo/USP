//Lista todas as funções que serão usadas no programa
int* preencherLista(int* vetor);
int* alocaMemoria(int* vetor, int *tamanho);
int* verificaPrimo(int* vetor, int n, int* tamanho);
int* adicionaLista(int *vetor, int* tamanho, int n);