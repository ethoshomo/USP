void push(char pilha[], int *tamanho, char caracter, char *topo);
void pop(char pilha[], int *tamanho, char *topo);
int leituraPilha();