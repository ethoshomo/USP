Arquivo zip gerado em: 23/11/2021 08:50:33 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Exercício 10