#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include "dicionario.h" 

#define NIVEL_MAXIMO 15
#define FRACAO_REFERENCIA 0.5

struct item_t {
    char verbete[51];
    char definicao[141];
    item **proximo; // Proximo item da skiplist
};

struct slista_t {
    int nivelMaximo; // Numero máximo de níveis
    float fracaoItem; // Usado no sorteio
    int novoNivel;
    int nivel; // Nivel atual
    item *inicio; // Ponteiro para o inicio da skiplist
};

void verificarBarraRN(){
    char ch = ' ';
    ch = getchar();
    if (ch != '\r'){ungetc(ch, stdin);}
    ch = getchar();
    if (ch != '\n'){ungetc(ch, stdin);}
}

int resolverLinha(skiplist *d, char verbete[], char definicao[]){
    int saida = 0;
    //int resposta = -1;
    //char ch = ' ';
    char auxiliar[51];

    saida = scanf("%50[^,\r,\n,' ']s", auxiliar);
    if (saida == EOF){return 1;}
    else if(strcmp(auxiliar, "insercao") == 0) {
        //printf("\nVOCE ENTROU NO MENU INSERCAO!\n");
        saida = scanf(" %50[^,' ',\r,\n]s", verbete);
        //printf("Verbete (SCANF): %s \n", verbete);
        saida = scanf(" %140[^,\r,\n]s", definicao);
        //printf("Definicao (SCANF): %s \n", definicao);
        inserirSkiplist(d, verbete, definicao);
        verificarBarraRN();
    }
    else if(strcmp(auxiliar, "alteracao") == 0) {
        //printf("\nVOCE ENTROU NO MENU ALTERACAO!\n");
        saida = scanf(" %50[^,' ',\r,\n]s", verbete);
        //printf("%s ", verbete);   
        saida = scanf(" %140[^,\r,\n]s", definicao);
        //printf("%s \n", definicao);
        alterarSkiplist(d, verbete, definicao);
        verificarBarraRN();

    }
    else if(strcmp(auxiliar, "remocao") == 0) {
        //printf("\nVOCE ENTROU NO MENU REMOCAO!\n");
        saida = scanf(" %50[^,\r,\n]s", verbete);
        //printf("%s ", verbete);
        removerSkiplist(d, verbete);
        verificarBarraRN();
    }
    else if(strcmp(auxiliar, "busca") == 0) {   
        //printf("\nVOCE ENTROU NO MENU BUSCA!\n");
        saida = scanf(" %50[^,\r,\n]s", auxiliar);
        //printf("%s ", auxiliar);
        buscarSkiplist(d, auxiliar);
        verificarBarraRN();
        //if (resposta == 1){printf("\nA busca para %s retornou 1.\n", verbete);}
    }
    else if(strcmp(auxiliar, "impressao") == 0) {
        //printf("\nVOCE ENTROU NO MENU IMPRESSAO!\n");
        saida = scanf(" %50[^,\r,\n]s", auxiliar);
        //printf("%s ", auxiliar);
        imprimirSkiplist(d, auxiliar, strlen(auxiliar));
        verificarBarraRN();
    }
    else{
        printf("Comando invalido. Tente novamente.");
        return 1;
    }
    return 0;
}


void inicializaVetor(char vetor[], int tamanho){
    for(int i = 0; i < tamanho; i++)
        vetor[i] = ' ';
}

int sorteiaNivel(skiplist *d){
    float randomico = (float)rand()/RAND_MAX;
    int nivel = 0;
    
    //Enquanto o valor randomico não está entre a fração de item
    // e o nivel maximo da lista, o nivel provisorio é incrementado 
    // de uma unidade. 
    while((randomico < d->fracaoItem) && (nivel < d->nivelMaximo)){
        nivel++;
        randomico = (float) rand()/RAND_MAX;
    }

    return nivel;
}

skiplist* criarSkiplist(skiplist *d){
    char verbete[51], definicao[141];
    inicializaVetor(verbete, 51);
    inicializaVetor(definicao, 141);

    d = (skiplist*)malloc(sizeof(skiplist));
    if (d != NULL){
        d->nivelMaximo = NIVEL_MAXIMO;
        d->fracaoItem = FRACAO_REFERENCIA;
        d->nivel = 0;
        d->novoNivel = 0;
        d->inicio = (item*)malloc(sizeof(item));
        strcpy(d->inicio->verbete, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        strcpy(d->inicio->definicao, "Inicializa menor valor possivel");
        d->inicio->proximo = (item**)malloc((d->nivelMaximo + 1)*sizeof(item*));
        for (int i = 0; i <= d->nivelMaximo; i++) {
            d->inicio->proximo[i] = NULL;
        }
        /*
        printf("Testando todas as variáveis de SKIPLIST:\n");
        printf("NivelMaximo: %d\n", d->nivelMaximo);
        printf("FracaItem: %f\n", d->fracaoItem);
        printf("Nivel:%d\n", d->nivel);
        printf("novoNivel: %d\n", d->novoNivel);
        printf("Inicio->Verbete: %s\n", d->inicio->verbete);
        printf("Inicio->Definicao: %s\n", d->inicio->definicao);
        printf("Inicio->Proximmo[0]: %p\n", d->inicio->proximo[0]);
        printf("Inicio->Proximmo[1]: %p\n", d->inicio->proximo[1]);
        printf("Inicio->Proximmo[2]: %p\n", d->inicio->proximo[2]);
        printf("Inicio->Proximmo[3]: %p\n", d->inicio->proximo[3]);
        */
    }   
    return d;
}

// Finalidade: a destruição da skiplist resume-se basicamente
// em percorrer a lista encadeada que possui todos os elementos (0).
// Desse modo, iremos desalocar todos os itens que foram inseridos
// e, logo em seguida, iremos fazer uma desalocação do cabeçalho.
// Retorno: não há.
void destruirSkiplist(skiplist *d){
    if (d == NULL){return;}

    item *itemPassado = NULL, *atual = NULL;
    
    if (d->inicio->proximo[0] != NULL){
        atual = d->inicio->proximo[0];

        while (atual != NULL){
            itemPassado = atual;
            atual = atual->proximo[0];
            free(itemPassado->proximo);
            free(itemPassado);
        }
    }

    free(d->inicio);
    free(d);
}

// Finalidade: inserir ou alterar itens. A ideia da função é buscar
// a posição de inserção em todos os niveis da skiplist e armazenar
// em um array temporário. Será alocada memória para o novo elemento
// bem como será sorteado quantos niveis ele terá. Caso tenha mais 
// níveis que o atual ocupado, atualiza o array temporário. Em seguida,
// a função faz a inserção do novo item usando os dados do auxiliar 
// (como se fosse lista encadeada).
// Retorno: retorna 0 para fracasso e 1 para sucesso.
int inserirSkiplist(skiplist *d, char verbete[], char definicao[]){
    if (d == NULL){return 0;}
    /*
    printf("\nDentro da função INSERIR/ATUALIZAR:\n");
    printf("Verbete a ser usado: %s\n", verbete);
    printf("Definicao a ser usada: %s\n\n", definicao);
    */
    int i;
    item *atual = d->inicio; // Ponteiro sentinela usado para percorrer a lista
    
    item **auxiliar = NULL;
    auxiliar = (item**)malloc((d->nivelMaximo +1)*sizeof(item*));
    for (i = 0; i <= d->nivelMaximo; i++)
        auxiliar[i] = NULL;

    d->novoNivel = sorteiaNivel(d);
    //printf("NovoNivel (sorteado): %d\n", d->novoNivel);

    // A ideia da função abaixo é começar pelo nivel mais alto,
    // realizar uma busca até o valor maior que o de inserção e,
    // depois de armazenar o endereço do próximo elemento no array 
    // auxiliar, descer um nível, mantendo a posição anterior. 
    // O processo se repete até que se tenha atingido menor nivel 
    // da lista. Ou seja, reserva-se todas as possíveis posições para
    // uso depois que o sorteio for realizado.
    for (i = d->nivel; i >= 0; i--){
        while((atual->proximo[i] != NULL) && (strcmp(atual->proximo[i]->verbete, verbete) < 0))
            atual = atual->proximo[i];
        auxiliar[i] = atual;
        //printf("Nivel: %d.\n", i);
    }
    
    //Acessa o item seguinte da sua posicao no nivel 0.
    atual = atual->proximo[0];

    //Em seguida, primeiro compara o verbete com o valor do atual.
    //Caso o verbete seja idêntico, altera sua definição.
    //Caso não exista, cria novo item e o insere.
    
    //printf("Chegou na parte da insercao:\n");
    //printf("Atual: %p\n", atual);

/*
if (atual != NULL){

    printf("\nVerbete: %s\n", verbete);
    printf("\nDefinicao: %s\n\n", definicao);
            printf("\nAnalisando o ponteiro atual:\n");
            printf("Atual->Verbete: %s\n", atual->verbete);
            printf("Atual->Definicao: %s\n", atual->definicao);
            printf("Atual->Proximo: %p\n", atual->proximo);
            printf("Atual->Proximo[nivel]: %p\n", atual->proximo[0]);

            printf("\n\nPonteiro PROXIMO DO ATUAL:\n");
            printf("Atual->Verbete: %s\n", atual->proximo[0]->verbete);
            printf("Atual->Definicao: %s\n", atual->proximo[0]->definicao);
            printf("Atual->Proximo: %p\n", atual->proximo[0]->proximo);
            printf("Atual->Proximo[nivel]: %p\n", atual->proximo[0]);

}
*/
    if ((atual != NULL) && (strcmp(atual->verbete, verbete) == 0)){
        printf("OPERACAO INVALIDA\n");
        return 0;
    }
    else{

        item *novo = NULL;
        novo = (item*)malloc(sizeof(item));
        if (novo == NULL){
            free(auxiliar);
            free(novo);
            return 0;
        }
        strcpy(novo->verbete, verbete);
        strcpy(novo->definicao, definicao);
        novo->proximo = (item**)malloc((d->nivelMaximo+1)*sizeof(item*));
        for(int k = 0; k < d->nivelMaximo; k++)
            novo->proximo[k] = NULL;
        /*
        printf("Novo->Verbete: %s\n", novo->verbete);
        printf("Novo->Definicao: %s\n", novo->definicao);
        printf("Novo->Proximo: %p\n", novo->proximo);
        printf("Novo->Proximo[0]: %p\n", novo->proximo[0]);
        printf("Novo->Proximo[1]: %p\n", novo->proximo[1]);
        printf("Novo->Proximo[2]: %p\n", novo->proximo[2]);
        printf("Novo->Proximo[3]: %p\n", novo->proximo[3]);
        */
        

        //Se o nivel sorteado for maior que o nivel atual
        //é necessário atualizar os novos niveis do auxiliar.
        if (d->novoNivel > d->nivel){
            for(i = d->nivel + 1; i <= d->novoNivel; i++)
                auxiliar[i] = d->inicio;
            d->nivel = d->novoNivel;
        }

        //Insere o novo item nas novas posições em niveis
        for(i = 0; i <= d->novoNivel; i++){
            novo->proximo[i] = auxiliar[i]->proximo[i];
            auxiliar[i]->proximo[i] = novo;
        } 
        //imprimirTODASkiplist(d);
        free(auxiliar);
    }

    return 1;
}

int alterarSkiplist(skiplist *d, char verbete[], char definicao[]){
    if (d == NULL){return 0;}
    /*
    printf("\nDentro da função INSERIR/ATUALIZAR:\n");
    printf("Verbete a ser usado: %s\n", verbete);
    printf("Definicao a ser usada: %s\n\n", definicao);
    */
    int i;
    item *atual = d->inicio; // Ponteiro sentinela usado para percorrer a lista
    
    //printf("NovoNivel (sorteado): %d\n", d->novoNivel);

    // A ideia da função abaixo é começar pelo nivel mais alto,
    // realizar uma busca até o valor maior que o de inserção e,
    // depois de armazenar o endereço do próximo elemento no array 
    // auxiliar, descer um nível, mantendo a posição anterior. 
    // O processo se repete até que se tenha atingido menor nivel 
    // da lista. Ou seja, reserva-se todas as possíveis posições para
    // uso depois que o sorteio for realizado.
    for (i = d->nivel; i >= 0; i--){
        while((atual->proximo[i] != NULL) && (strcmp(atual->proximo[i]->verbete, verbete) < 0))
            atual = atual->proximo[i];
        //printf("Nivel: %d.\n", i);
    }

    //Acessa o item seguinte da sua posicao no nivel 0.
    atual = atual->proximo[0];

    if (strcmp(atual->verbete, verbete) == 0){
        strcpy(atual->definicao, definicao);
    }
    else if (strcmp(atual->verbete, verbete) !=0){
        printf("OPERACAO INVALIDA\n");
    }

    return 1;
}



// Semelhante a inserção, deve-se buscar em cada nível
// a posição que o verbete se encontra e, por meio de
// um array auxiliar, armazena informações necessárias.
// Porém, se no nivel ZERO o auxiliar aponta para o
// elemento a ser removido, ele deverá apontar para o
// próximo elemento (similar a lista encadeada).
// Retorno: 1 para sucesso e 0 para fracasso.
int removerSkiplist(skiplist *d, char verbete[]){
    if (d == NULL){return 0;}

    int i;
    item *atual = d->inicio;
    item **auxiliar = NULL;
    auxiliar = (item**)malloc((d->nivelMaximo+1)*sizeof(item*));

    for(i = 0; i <= d->nivelMaximo; i++){
        auxiliar[i] = NULL;
    }

    //Reserva todas as posições de inserção no vetor auxiliar.
    for(i = d->nivel; i >= 0; i--){
        while((atual->proximo[i] != NULL) && (strcmp(atual->proximo[i]->verbete, verbete) < 0))
            atual = atual->proximo[i];
        auxiliar[i] = atual;
    }

    atual = atual->proximo[0];
    
    //Caso o elemento a ser removido exista, toma providências.
    if((atual != NULL) && (strcmp(atual->verbete, verbete) == 0)){
        // Começando no nível zero, se o atual aponta para aquele que se 
        // deseja remover, deve-se reservar os próximos (similar 
        // a lista encadeada).
        for(i = 0; i <= d->nivel; i++){
            if (auxiliar[i]->proximo[i] != atual) {break;}
            auxiliar[i]->proximo[i] = atual->proximo[i];
        }

        //Remove setas que atrapalhariam a busca e a skiplist
        while((d->nivel > 0) && (d->inicio->proximo[d->nivel] == NULL))
            d->nivel--;
        //printf("O verbete %s foi removido com sucesso. Eis sua definição:\n%s\n", atual->verbete, atual->definicao);
        free(atual->proximo);
        free(atual);
        free(auxiliar);
        return 1;
    }
    else{
        printf("OPERACAO INVALIDA\n");
    }

    free(auxiliar);
    return 0;
}

// Partindo do maior nível, segue a sequência de próximos
// itens enquanto o verbete buscado seja maior que o valor 
// do próximo. Caso contrário, desce de nível e continua a
// busca até atingir o nível zero. Caso exista, o verbete
// deverá estar no próximo item do nível zero.
int buscarSkiplist(skiplist *d, char verbete[]){
    if (d == NULL) {return 0;}
    //printf("\nBUSCA DE VERBETE (DENTRO DA FUNCAO)\n");
    item *atual = d->inicio;
    /*
    printf("Analisando o ponteiro atual:\n");
        printf("Atual->Verbete: %s\n", atual->verbete);
        printf("Atual->Definicao: %s\n", atual->definicao);
        printf("Atual->Proximo: %p\n", atual->proximo);
        printf("Atual->Proximo[0]: %p\n", atual->proximo[0]);
        printf("Atual->Proximo[1]: %p\n", atual->proximo[1]);
        printf("Atual->Proximo[2]: %p\n", atual->proximo[2]);
        printf("Atual->Proximo[3]: %p\n\n", atual->proximo[3]);

    printf("A variável d->nivel: %d:\n\nENTRAREMOS NA BUSCA ABAIXO:", d->nivel);*/
    int i;
    for(i = d->nivel; i >= 0; i--){
          

        while((atual->proximo[i] != NULL) && (strcmp(atual->proximo[i]->verbete, verbete) < 0)){
            atual = atual->proximo[i];
        }
    }

    atual = atual->proximo[0];
    

            //printf("\n. PONTEIRO ATUAL: %p.\nVERBETE BUSCADO: %s\n", atual, verbete);
           // printf("Atual->Verbete: %s\n", atual->verbete);
           // printf("Atual->Definicao: %s\n", atual->definicao);
            //printf("Atual->Proximo: %p\n", atual->proximo);
           // printf("Atual->Proximo[nivel]: %p\n", atual->proximo[i]);

            //printf("Ponteiro PROXIMO DO ATUAL:\n");
            //printf("Atual->Verbete: %s\n", atual->proximo[i]->verbete);
            //printf("Atual->Definicao: %s\n", atual->proximo[i]->definicao);
            //printf("Atual->Proximo: %p\n", atual->proximo[i]->proximo);
            //printf("Atual->Proximo[nivel]: %p\n", atual->proximo[i]);           


    if((atual != NULL) && (strcmp(atual->verbete, verbete) == 0)) {
        printf("%s %s\n", atual->verbete, atual->definicao);
        return 1;
    }
    else{
        printf("OPERACAO INVALIDA\n");
    }

    return 0;
}

// A função percorre todo o dicionário buscando as palavras que são
// candidatas a impressão.
// Retorno: não há.
void imprimirSkiplist(skiplist *d, char trecho[], int tamanho){
    if (d == NULL) {return;}
    item *atual = NULL;
    int impressao = 0;

    atual = d->inicio->proximo[0];
    /*
    printf("\nTRECHO: %s\n", trecho);
    printf("\nTamanho: %d\n", tamanho);
            printf("\nAnalisando o ponteiro atual:\n");
            printf("Atual->Verbete: %s\n", atual->verbete);
            printf("Atual->Definicao: %s\n", atual->definicao);
            printf("Atual->Proximo: %p\n", atual->proximo);
            printf("Atual->Proximo[nivel]: %p\n", atual->proximo[0]);

            printf("\n\nPonteiro PROXIMO DO ATUAL:\n");
            printf("Atual->Verbete: %s\n", atual->proximo[0]->verbete);
            printf("Atual->Definicao: %s\n", atual->proximo[0]->definicao);
            printf("Atual->Proximo: %p\n", atual->proximo[0]->proximo);
            printf("Atual->Proximo[nivel]: %p\n", atual->proximo[0]);
*/
    while (atual != NULL) {
        if (strncmp(atual->verbete, trecho, tamanho) == 0){
            printf("%s %s\n", atual->verbete, atual->definicao);
            impressao += 1;
        }
        atual = atual->proximo[0];
    }
    
    if (impressao == 0){printf("NAO HA PALAVRAS INICIADAS POR %s\n", trecho);}
    
    return;
}

